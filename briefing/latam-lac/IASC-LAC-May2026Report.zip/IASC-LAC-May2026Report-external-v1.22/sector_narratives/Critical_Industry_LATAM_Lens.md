# Critical Industry LATAM Lens - React2Shell Exploit Scanning - ILOVEPOOP Toolkit

The broader critical-industry lane contains telecom/ISP, cloud/provider, energy, water, public-sector, industrial/manufacturing, transportation/logistics, education/research, IT/software/security, healthcare, and banking rows.

Top critical-industry rows:

| src_Netname | count | country_inferred | sector_primary | lac_csirt_priority |
| --- | --- | --- | --- | --- |
| Telecom Argentina S.A. | 31,537 | Argentina | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| VTR BANDA ANCHA S.A. | 21,141 | Chile | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| ETB - Colombia | 4,618 | Colombia | Telecommunications/ISP | P2 - Colombia provider/sector validation |
| VIETTEL PERÚ S.A.C. | 4,090 | Peru | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| Red Cientifica Peruana | 3,243 | Peru | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| TIM S/A | 2,770 | Brazil | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| Gigared S.A. | 2,529 | LATAM/LAC unspecified | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| Cirion Technologies do Brasil Ltda. | 2,132 | Brazil | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| IFX Networks Venezuela C.A. | 2,069 | Venezuela | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| CIRION TECHNOLOGIES ARGENTINA S.A. | 2,024 | Argentina | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| Entel PCS Telecomunicaciones S.A. | 1,406 | LATAM/LAC unspecified | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| Huawei-Cloud-Brazil | 1,376 | Brazil | Cloud/Hosting/CDN | P2 - high-volume provider-mediated validation |
| ENTEL CHILE S.A. | 1,316 | Chile | Telecommunications/ISP | P2 - high-volume provider-mediated validation |
| TV AZTECA SUCURSAL COLOMBIA | 1,260 | Colombia | Telecommunications/ISP | P2 - Colombia provider/sector validation |
| UFINET COLOMBIA, S. A. | 1,139 | Colombia | Telecommunications/ISP | P2 - Colombia provider/sector validation |
| IFX NETWORKS COLOMBIA | 990 | Colombia | Telecommunications/ISP | P2 - Colombia provider/sector validation |
| Level 3 Colombia S.A. | 973 | Colombia | Telecommunications/ISP | P2 - Colombia provider/sector validation |
| IFX Networks Argentina S.R.L. | 651 | Argentina | Telecommunications/ISP | P2 - sector validation / enrichment |
| Huawei-Cloud-Chile | 568 | Chile | Cloud/Hosting/CDN | P2 - sector validation / enrichment |
| CANTV Servicios, Venezuela | 534 | Venezuela | Telecommunications/ISP | P2 - sector validation / enrichment |
| COMPA�IA PARAGUAYA DE COMUNICACIONES S.A. (COPACO S.A.) | 506 | Paraguay | Telecommunications/ISP | P2 - sector validation / enrichment |
| Level 3 Peru S.A. | 413 | Peru | Telecommunications/ISP | P2 - sector validation / enrichment |
| LetsCloud Brasil | 401 | Brazil | Cloud/Hosting/CDN | P2 - sector validation / enrichment |
| HUGHES TELECOMUNICACOES DO BRASIL LTDA. | 390 | Brazil | Telecommunications/ISP | P2 - sector validation / enrichment |
| S. O. do Brasil Telecomunica��es LTDA ME | 381 | Brazil | Telecommunications/ISP | P2 - sector validation / enrichment |

Operational framing: most volume is provider-mediated. The priority is validation workflow, not attribution or victim claims.

Regional probing note: the same attackers associated with ILOVEPOOP exploit scanning produced 158K+ LAC/LATAM source-side observations, suggesting reconnaissance pressure that warrants proactive validation before any public attribution or victim naming.

CTA: **iasc@whoisxmlapi.com**
