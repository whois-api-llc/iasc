# Healthcare CSIRT Lens - React2Shell Exploit Scanning - ILOVEPOOP Toolkit LAC/LATAM

Healthcare rows are low-volume but high-sensitivity. This queue should be used for quiet validation of exposed Next.js/React Server Components assets and edge logs, not public victim naming.

Key rows:

| src_Netname | count | country_inferred | sector_primary | lac_csirt_priority |
| --- | --- | --- | --- | --- |
| OXIGENOS DE COLOMBIA LTDA | 16 | Colombia | Healthcare/Life Sciences | P1 - Colombia direct critical-sector validation |
| UNIMED DO BRASIL CONF NAC DAS COOPERATIVAS MEDICAS | 8 | Brazil | Healthcare/Life Sciences | P2 - sector validation / enrichment |
| SISTEMAS TELECOMUNICACIONES Y BIOMEDICOS DE COLOMBIA S.A.S | 7 | Colombia | Telecommunications/ISP | P2 - Colombia provider/sector validation |
| BMI IGUALAS MEDICAS DEL ECUADOR S.A | 4 | Ecuador | Healthcare/Life Sciences | P2 - sector validation / enrichment |
| NI-PUBLIC---HEALTH | 4 | Nicaragua | Healthcare/Life Sciences | P2 - sector validation / enrichment |
| AGFA HEALTHCARE IT BRASIL SERVI�OS E INFORMATICA L | 3 | Brazil | Healthcare/Life Sciences | P2 - sector validation / enrichment |
| SALUDSA SISTEMA DE MEDICINA PREPAGADA DEL ECUADOR S.A. | 2 | Ecuador | Healthcare/Life Sciences | P2 - sector validation / enrichment |
| FRESENIUS MEDICAL CARE ARGENTINA SA | 2 | Argentina | Healthcare/Life Sciences | P2 - sector validation / enrichment |
| ASEPSIS PRODUCTS DE COLOMBIA LTDA PROASEPSIS LTDA | 1 | Colombia | Healthcare/Life Sciences | P1 - Colombia direct critical-sector validation |
| HEALTH PRIME COLOMBIA S.A.S. | 1 | Colombia | Healthcare/Life Sciences | P1 - Colombia direct critical-sector validation |
| NOVO NORDISK PHARMA ARGENTINA S.A. | 1 | Argentina | Healthcare/Life Sciences | P2 - sector validation / enrichment |
| Laboratorios Rene Chardon del Ecuador Cia. Ltda. | 1 | Ecuador | Healthcare/Life Sciences | P2 - sector validation / enrichment |
| NOVO NORDISK FARMACEUTICA DO BRASIL LTDA | 1 | Brazil | Healthcare/Life Sciences | P2 - sector validation / enrichment |

Recommended ask: search for the two exploit servers, ILOVEPOOP headers, `/ _next` route probes without the space, and evidence of patch/exposure state during December 2025-February 2026.

CTA: **iasc@whoisxmlapi.com**
