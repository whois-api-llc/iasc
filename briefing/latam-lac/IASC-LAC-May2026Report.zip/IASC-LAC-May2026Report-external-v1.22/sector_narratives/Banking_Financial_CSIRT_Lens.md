# Banking and Financial CSIRT Lens - React2Shell Exploit Scanning - ILOVEPOOP Toolkit LAC/LATAM

The banking lane is one of the clearest direct-sector queues. Start with named banks, central banks, insurers, payment processors, and market infrastructure before moving to provider-mediated rows.

Key rows:

| src_Netname | count | country_inferred | sector_primary | lac_csirt_priority |
| --- | --- | --- | --- | --- |
| BANCO DO NORDESTE DO BRASIL S/A | 1,013 | Brazil | Financial Services | P1 - LATAM direct critical-sector validation |
| Corporacion Banco de Chile | 532 | Chile | Financial Services | P1 - LATAM direct critical-sector validation |
| BANCO DO BRASIL S.A. | 468 | Brazil | Financial Services | P1 - LATAM direct critical-sector validation |
| BANCO DE LA PROVINCIA DE BUENOS AIRES | 104 | Argentina | Financial Services | P1 - LATAM direct critical-sector validation |
| PAGSEGURO INTERNET S.A. | 99 | Brazil | Telecommunications/ISP | P2 - sector validation / enrichment |
| BANCO MACRO BMA S.A.U | 86 | Argentina | Financial Services | P1 - LATAM direct critical-sector validation |
| BANCO MUNICIPAL DE ROSARIO | 42 | Argentina | Financial Services | P1 - LATAM direct critical-sector validation |
| Banco BMG S.A. | 35 | Brazil | Financial Services | P1 - LATAM direct critical-sector validation |
| CAIXA SEGURADORA S.A. | 27 | Brazil | Financial Services | P1 - LATAM direct critical-sector validation |
| FD DO BRASIL SOLU��ES DE PAGAMENTOS LTDA | 18 | Brazil | Financial Services | P1 - LATAM direct critical-sector validation |
| BANCO CENTRAL DE LA REPUBLICA ARGENTINA | 18 | Argentina | Financial Services | P1 - LATAM direct critical-sector validation |
| Banco Central de Chile | 17 | Chile | Financial Services | P1 - LATAM direct critical-sector validation |
| BANCO DEL PACIFICO S.A. | 16 | Ecuador | Financial Services | P1 - LATAM direct critical-sector validation |
| BANCO GUAYAQUIL | 12 | Ecuador | Financial Services | P1 - LATAM direct critical-sector validation |
| CAIXA-PENEDES | 10 | Brazil | Financial Services | P1 - LATAM direct critical-sector validation |
| BANCOLOMBIA S.A. | 6 | Colombia | Financial Services | P1 - Colombia direct critical-sector validation |
| BANCO GNB PARAGUAY SOCIEDAD ANONIMA EMISORA DE CAPITAL ABIERTO | 5 | Paraguay | Financial Services | P2 - sector validation / enrichment |
| BANCOLOMBIA S.A | 4 | Colombia | Financial Services | P1 - Colombia direct critical-sector validation |
| BANCO RCI BRASIL S/A | 4 | Brazil | Financial Services | P2 - sector validation / enrichment |
| : ANTARTIDA COMPAÑIA ARGENTINA DE SEGUROS SOCIEDAD | 4 | Argentina | Financial Services | P2 - sector validation / enrichment |

Recommended ask: validate whether any internet-facing web edge, WAF, reverse proxy, developer environment, or SaaS-hosted Next.js asset contacted or was contacted by the two exploit servers.

CTA: **iasc@whoisxmlapi.com**
