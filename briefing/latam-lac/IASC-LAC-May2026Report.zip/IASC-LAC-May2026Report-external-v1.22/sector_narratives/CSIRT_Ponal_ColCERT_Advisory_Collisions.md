# CSIRT-Ponal & ColCERT Advisory Collisions - Colombia Critical Industries Lens

Colombia has 173 netnames and 11,108 source-side observation count in this pass. The first queue is provider-mediated validation; the second is a lower-volume direct critical-sector validation queue.

Direct P1 Colombia rows:

| src_Netname | count | sector_primary | sector_secondary | source_type_lens |
| --- | --- | --- | --- | --- |
| OXIGENOS DE COLOMBIA LTDA | 16 | Healthcare/Life Sciences |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| OLEODUCTO BICENTENARIO DE COLOMBIA S.A.S. | 10 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| BANCOLOMBIA S.A. | 6 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| Empresa de Acueducto y Alcantarillado de Bogotá | 6 | Water/Sanitation | Education/Research | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| PRIMAX COLOMBIA S A | 5 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| COMBUSTIBLES DE COLOMBIA S.A | 5 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| BANCOLOMBIA S.A | 4 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| EMERALD ENERGY PLC SUCURSAL COLOMBIA | 4 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| Empresa de Acueducto y Alcantarillado de Bogotá - ESP | 3 | Water/Sanitation | Education/Research | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| ASEGURADORA SOLIDARIA DE COLOMBIA | 2 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| AGUAS DE BOGOTA S A ESP | 2 | Water/Sanitation |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| ASEPSIS PRODUCTS DE COLOMBIA LTDA PROASEPSIS LTDA | 1 | Healthcare/Life Sciences |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| GAS PETROLEO Y DERIVADOS DE COLOMBIA S.A.S | 1 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| Aseguradora Solidaria de Colombia Ltda. | 1 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| OILTANKING COLOMBIA S.A. | 1 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| HEALTH PRIME COLOMBIA S.A.S. | 1 | Healthcare/Life Sciences |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| BOLSA DE VALORES DE COLOMBIA | 1 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| ASEGURADORA SOLIDARIA DE COLOMBIA ENTIDA | 1 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |

Provider/sector rows:

| src_Netname | count | sector_primary | source_type_lens |
| --- | --- | --- | --- |
| ETB - Colombia | 4,618 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| TV AZTECA SUCURSAL COLOMBIA | 1,260 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| UFINET COLOMBIA, S. A. | 1,139 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| IFX NETWORKS COLOMBIA | 990 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| Level 3 Colombia S.A. | 973 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| SKYNET DE COLOMBIA S.A. ESP | 263 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| Une Telecom Ltda | 227 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| FIBRA OPTICA COLOMBIA S.A.S. ZOMAC | 213 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| Universidad Nacional de Colombia | 208 | Education/Research | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| HUGHES DE COLOMBIA S.A.S. | 161 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| Telmex Colombia S.A. | 71 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| INTERNET-COLOMBIA | 63 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| Starlink Colombia S.A.S. | 49 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| IPXON Networks Colombia | 46 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| GIGAS HOSTING COLOMBIA S.A.S. | 29 | Cloud/Hosting/CDN | shared hosting/cloud/CDN - tenant validation needed |
| AT&T GLOBAL NETWORKS SERVICES COLOMBIA | 22 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| ESRI COLOMBIA SAS | 19 | IT/Software/Security | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| GlobeNet Cabos Submarinos Colombia, S.A.S. | 15 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| ETB | 11 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| GEODIS COLOMBIA LTDA | 9 | Transportation/Logistics | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| CENTURYLINK COLOMBIA S.A. | 8 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| CLOUDSTAFF COLOMBIA S.A.S | 8 | Cloud/Hosting/CDN | shared hosting/cloud/CDN - tenant validation needed |
| ORANGE BUSINESS SERVICES COLOMBIA S.A. | 8 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| MAZDA DE COLOMBIA S.A.S. | 7 | Industrial/Manufacturing | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| SISTEMAS TELECOMUNICACIONES Y BIOMEDICOS DE COLOMBIA S.A.S | 7 | Telecommunications/ISP | provider/access network - provider-mediated validation |

Recommended ask: coordinate with national and sectoral CSIRT channels. Use the provider lane to resolve tenant ownership and the direct lane to ask for local log confirmation.

Narrative note: this uses overlap between WXA traffic visibility and infrastructure described in PONAL / ColCERT advisories. The key facts are 35,686 exact IP:port overlaps, 444K+ matched flow rows, and 6,086 unique Colombia peer IPs. It is a validation-first visibility lens, not a partnership assertion or proof-of-compromise statement.

CTA: **iasc@whoisxmlapi.com**
