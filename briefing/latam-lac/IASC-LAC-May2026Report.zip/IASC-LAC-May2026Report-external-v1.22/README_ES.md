# Informe IASC LAC Mayo 2026

## Descripción

Este paquete contiene la versión externa del informe IASC LAC Mayo 2026.

## Contenido

- Archivos del reporte y recursos asociados.
- Estructura de carpetas renombrada para coincidir con el título oficial del archivo ZIP:
  `IASC-LAC-May2026Report-external-v1.22`

## Notas

- Esta versión está destinada para distribución externa.
- Todos los enlaces y referencias internas fueron actualizados para coincidir con el nuevo nombre de la carpeta raíz.

