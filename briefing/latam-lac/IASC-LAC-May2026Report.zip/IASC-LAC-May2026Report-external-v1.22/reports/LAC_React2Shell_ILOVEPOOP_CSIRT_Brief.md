# Latin America & Caribbean Attack Visibility: React2Shell Exploit Scanning - ILOVEPOOP Toolkit CSIRT Intelligence Brief

**Prepared for:** national CSIRTs, sectoral CSIRTs, healthcare SOCs, banking SOCs, critical-industry defenders, and trusted validation partners.
**Scope:** This brief extends the February 2026 *To Cache A Predator* React2Shell/ILOVEPOOP report with a new categorization pass over the attached LAC/LATAM source-netname NetFlow CSVs.
**Primary caveat:** NetFlow-derived interaction with the two exploit servers is evidence for validation and outreach. It is **not** proof of successful exploitation, compromise, data access, or victim status.

## How to read this brief

- **What happened:** two major React2Shell exploit servers aggressively probed 14M+ unique IP addresses.
- **Why LAC matters:** the same exploit-scanning infrastructure produced 158K+ regional observations across LAC/LATAM netnames.
- **How to act:** treat the queues as validation leads; confirm ownership, exposure, logs, and patch state before escalation.
- **How IASC helps:** CSIRTs and partners can arrive with current signal, historical context, and a broader task-force bench behind them.

## 1. What the February 2026 report established

The original report described React2Shell activity around two Netherlands-hosted systems: `193.142.147[.]209` (Colocatel-IP-Range) and `87.121.84[.]24` (VPSVAULT.HOST). The strongest narrative is that these two major exploit servers aggressively probed **14M+ unique IP addresses** and sat inside a 22,311,468-record NetFlow picture across 2025-11-01 to 2026-02-03. WXA IASC identified the ILOVEPOOP React2Shell toolkit as a coherent nine-node operator toolchain.

The toolkit signature is unusually useful for defenders: `Next-Action: x`, a static `X-Nextjs-Request-Id: poop1234`, per-attempt `X-Nextjs-Html-Request-Id: ilovepoop_*`, WebKit multipart boundaries, and a repeated path sweep through `/`, `/_next`, `/api`, `/_next/server`, `/app`, and `/api/route`. The report also described adjacent scanning against `/_next/static/*`, `/_next/data/*`, `/.next/`, DNP3, Telnet, SMB, RDP, SSH, HTTP, and related services.

## 2. What February 2026 external coverage added

The attached article set shows how the research was received externally: early February writeups repeated the core WXA IASC finding that React2Shell exploitation was active in the wild and that ILOVEPOOP had a distinctive detection signature; later coverage framed the toolkit as a state-linked exposure-scanning tool aimed at high-value networks; other coverage broadened the story into nation-state/cybercrime exploitation and the long tail of React2Shell ecosystem risk. The LAC analysis below should be interpreted as a follow-on regional validation lens, not as a new compromise assertion.

## 3. Latin America & Caribbean Probing

The same nation-state attackers who leveraged the ILOVEPOOP toolkit produced **158,093 LAC/LATAM source-side probe observations** across **1,389 in-scope netnames**. That pattern suggests reconnaissance pressure that could precede future state-directed activity against probed targets. The correct CSIRT posture is therefore proactive validation: ask for local logs, ownership context, app exposure state, and patch history without treating the queue as a public victim list.

WXA IASC's value is not just another IOC list. The program helps CSIRTs get more effective cooperation by showing up to incidents with current signal, historical signal, sector context, and a larger task-force bench behind them.

| Metric | Value |
|---|---:|
| Input netnames in categorized-only CSV | 1,859 |
| In-scope LAC/LATAM netnames after categorization pass | 1,389 |
| In-scope LAC/LATAM source-side probe observations | 158,093 |
| Colombia-focused netnames | 173 |
| Colombia-focused source-side observations | 11,108 |
| Healthcare/life-sciences rows | 13 |
| Healthcare/life-sciences observations | 51 |
| Banking/financial rows | 54 |
| Banking/financial observations | 2,570 |
| Broader critical-industry rows | 393 |
| Broader critical-industry observations | 98,133 |
| P1 direct critical-sector validation leads | 39 |

### Sector distribution

| Sector | Rows | Observation count |
|---|---:|---:|
| Telecommunications/ISP | 232 | 94,114 |
| Other/Unclassified | 862 | 53,364 |
| Education/Research | 33 | 3,608 |
| Cloud/Hosting/CDN | 26 | 2,670 |
| Financial Services | 53 | 2,471 |
| IT/Software/Security | 53 | 676 |
| Energy/Utilities | 38 | 523 |
| Retail/eCommerce | 24 | 361 |
| Media/Entertainment | 12 | 107 |
| Transportation/Logistics | 19 | 74 |
| Healthcare/Life Sciences | 12 | 44 |
| Industrial/Manufacturing | 13 | 32 |

### Country / regional concentration

| Country / scope | Rows | Observation count |
|---|---:|---:|
| Argentina | 203 | 36,597 |
| Trinidad and Tobago | 138 | 32,417 |
| Chile | 78 | 25,998 |
| Brazil | 421 | 18,357 |
| Colombia | 173 | 11,108 |
| Peru | 134 | 9,888 |
| Haiti | 4 | 8,907 |
| LATAM/LAC unspecified | 51 | 6,295 |
| Mexico | 22 | 3,190 |
| Venezuela | 28 | 2,782 |
| Ecuador | 55 | 791 |
| Bolivia | 13 | 603 |

## 4. CSIRT-Ponal & ColCERT Advisory Collisions

This section focuses on overlap between WXA traffic visibility and infrastructure described in recent PONAL and ColCERT advisories. WXA observed 35,686 exact IP:port overlaps, 444K+ matched flow rows, and 6,086 unique Colombia peer IPs. The value is the overlap itself: a validation-first queue for responders, not a partnership claim or a proof-of-compromise statement.

Colombia is the most actionable national lane in this pass because the data contains both high-volume provider networks and named direct critical-sector organizations. The provider-mediated lane is led by ETB, TV Azteca Colombia, UFINET Colombia, IFX Networks Colombia, Level 3 Colombia, Une Telecom, Fibra Optica Colombia, Hughes Colombia, Telmex Colombia, Starlink Colombia, IPXON, AT&T/Orange Business, and related infrastructure names. These should be handled as provider validation and routing questions first: request local flow/PCAP, NAT/CGNAT context, customer ownership, and HTTP/WAF logs before naming a downstream organization.

The direct Colombia P1 lane is lower-volume but higher sensitivity. It includes healthcare/life-sciences, banking/insurance/market infrastructure, water, oil/gas, and energy names. These rows are better suited for direct sectoral CSIRT notification or quiet bilateral validation.

### Colombia P1 direct critical-sector validation leads

| src_Netname | count | sector_primary | sector_secondary | source_type_lens |
| --- | ---: | --- | --- | --- |
| OXIGENOS DE COLOMBIA LTDA | 16 | Healthcare/Life Sciences |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| OLEODUCTO BICENTENARIO DE COLOMBIA S.A.S. | 10 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| BANCOLOMBIA S.A. | 6 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| Empresa de Acueducto y Alcantarillado de Bogotá | 6 | Water/Sanitation | Education/Research | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| PRIMAX COLOMBIA S A | 5 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| COMBUSTIBLES DE COLOMBIA S.A | 5 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| BANCOLOMBIA S.A | 4 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| EMERALD ENERGY PLC SUCURSAL COLOMBIA | 4 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| Empresa de Acueducto y Alcantarillado de Bogotá - ESP | 3 | Water/Sanitation | Education/Research | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| ASEGURADORA SOLIDARIA DE COLOMBIA | 2 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| AGUAS DE BOGOTA S A ESP | 2 | Water/Sanitation |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| ASEPSIS PRODUCTS DE COLOMBIA LTDA PROASEPSIS LTDA | 1 | Healthcare/Life Sciences |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| GAS PETROLEO Y DERIVADOS DE COLOMBIA S.A.S | 1 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| Aseguradora Solidaria de Colombia Ltda. | 1 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| OILTANKING COLOMBIA S.A. | 1 | Energy/Utilities |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| HEALTH PRIME COLOMBIA S.A.S. | 1 | Healthcare/Life Sciences |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| BOLSA DE VALORES DE COLOMBIA | 1 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| ASEGURADORA SOLIDARIA DE COLOMBIA ENTIDA | 1 | Financial Services |  | likely dedicated organization - validate with RDAP/WHOIS and local logs |

### Colombia provider/sector validation leads

| src_Netname | count | sector_primary | source_type_lens |
| --- | ---: | --- | --- |
| ETB - Colombia | 4,618 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| TV AZTECA SUCURSAL COLOMBIA | 1,260 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| UFINET COLOMBIA, S. A. | 1,139 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| IFX NETWORKS COLOMBIA | 990 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| Level 3 Colombia S.A. | 973 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| SKYNET DE COLOMBIA S.A. ESP | 263 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| Une Telecom Ltda | 227 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| FIBRA OPTICA COLOMBIA S.A.S. ZOMAC | 213 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| Universidad Nacional de Colombia | 208 | Education/Research | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| HUGHES DE COLOMBIA S.A.S. | 161 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| Telmex Colombia S.A. | 71 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| INTERNET-COLOMBIA | 63 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| Starlink Colombia S.A.S. | 49 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| IPXON Networks Colombia | 46 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| GIGAS HOSTING COLOMBIA S.A.S. | 29 | Cloud/Hosting/CDN | shared hosting/cloud/CDN - tenant validation needed |
| AT&T GLOBAL NETWORKS SERVICES COLOMBIA | 22 | Telecommunications/ISP | provider/access network - provider-mediated validation |
| ESRI COLOMBIA SAS | 19 | IT/Software/Security | likely dedicated organization - validate with RDAP/WHOIS and local logs |
| GlobeNet Cabos Submarinos Colombia, S.A.S. | 15 | Telecommunications/ISP | provider/access network - provider-mediated validation |

## 5. Healthcare CSIRT lens

This section focuses on overlap between WXA traffic and infrastructure referenced in CSIRT Salud advisories. WXA observed 24,421 collided flow records, saw 13 of 19 advisory IPs in sampled traffic, and surfaced 3,459 unique peer IPs for follow-up. The correct posture is validation-first: use the overlap to guide quiet outreach and local checking, not to overclaim compromise or partnership.

For healthcare defenders, the practical next step is to validate the surfaced peer IPs, timestamps, and associated netnames against local logs, edge-device telemetry, and proxy or application records.

## 6. Banking and financial CSIRT lens

The banking/financial lane includes direct financial institutions and adjacent payment, insurance, and market infrastructure names such as Banco do Nordeste, Banco de Chile, Banco do Brasil, Banco Macro, Banco Municipal de Rosario, Banco Central de la Republica Argentina, Banco Central de Chile, Banco del Pacifico, Banco Guayaquil, Bancolombia, insurers, payment processors, and market-infrastructure names.

Banking CSIRTs should prioritize direct institution validation first, then shared provider paths. The practical question is whether any application edge, WAF, reverse proxy, CI/CD preview environment, or developer-hosted Next.js asset saw the exploit servers or toolkit headers. This is exactly the sort of workflow where an IASC-style collective helps: the CSIRT brings local logs, while WXA brings historical probes, peer visibility, and correlation context.

## 7. Critical industry lens for greater LATAM

The broader critical-industry story is dominated by telecom/ISP and provider-mediated validation. That is expected for source-side NetFlow data and should not be collapsed into victim naming. Provider rows are still operationally valuable because they can reveal whether the traffic belonged to provider infrastructure, a customer, CGNAT, a cloud tenant, or a hosted application.

Energy, water, oil/gas, electric cooperatives, industrial/manufacturing, transportation/logistics, IT/software/security, public sector, and education names form the lower-volume but higher-specificity queue. These are the rows where national CSIRTs and sectoral ISAC/CSIRT partners can coordinate quiet validation with better evidence and a larger task force behind them.

## 8. Recommended CSIRT action path

1. **Do not publish a victim list.** Treat this as an outreach and validation package.
2. **Start with the two exploit servers.** Hunt for `193.142.147[.]209` and `87.121.84[.]24` in NetFlow, proxy, WAF, firewall, DNS, EDR network telemetry, and packet captures.
3. **Layer in toolkit selectors.** Search HTTP logs for `Next-Action: x`, `X-Nextjs-Request-Id: poop1234`, `X-Nextjs-Html-Request-Id: ilovepoop_*`, and multipart WebKit boundaries.
4. **Confirm app exposure.** Identify internet-facing Next.js / React Server Components deployments active from 2025-11-01 through 2026-02-06.
5. **Separate provider from tenant.** For ISP, cloud, CDN, hosting, and access-network names, ask the provider to resolve customer ownership and timestamps before sector notification.
6. **Validate P1 direct critical rows quietly.** Prioritize Colombia direct critical-sector rows plus banking/healthcare/energy/water rows across LATAM.
7. **Feed back outcomes.** Mark each lead as confirmed local hit, false positive/shared infra, unowned/tenant unresolved, blocked, patched, or needs more data.
8. **Bring the collective into the loop.** WXA IASC can help package current signal, historical context, and cross-partner validation so CSIRTs are not entering incidents with one-off indicators alone.

## 9. Package contents

- Enriched CSVs with `country_inferred`, `sector_primary`, `sector_all`, `source_type_lens`, CSIRT relevance flags, and `lac_csirt_priority`.
- Colombia-only validation queue.
- LAC/LATAM CSIRT triage queue.
- IOC and hunting selector CSVs.
- Updated WXA IASC partner briefing with the `LAC REACT2SHELL EXPLOIT SCANNING - ILOVEPOOP TOOLKIT` toggle and research tab.
- Validation language and outreach guidance for trusted CSIRT/SOC workflows.

## Contact

# iasc@whoisxmlapi.com
