# CSIRT Validation Notification Template - React2Shell / ILOVEPOOP

Subject: Request for local validation - React2Shell / ILOVEPOOP exploit-scanning interaction

Hello [CSIRT / SOC / provider team],

WXA IASC observed a NetFlow-derived interaction involving a network name associated with your country/sector and two high-confidence React2Shell exploitation pivots: `193.142.147[.]209` and `87.121.84[.]24`.

This notification is **not** an assertion of compromise. We are asking for local validation because flow telemetry alone cannot determine whether the traffic reflects provider infrastructure, customer/tenant infrastructure, scan response behavior, NAT/CGNAT, or a vulnerable application.

Requested validation:

1. Search NetFlow, firewall, proxy, WAF, EDR, and packet capture records for the two IPs above between 2025-11-01 and 2026-02-06.
2. Search HTTP logs for `Next-Action: x`, `X-Nextjs-Request-Id: poop1234`, `X-Nextjs-Html-Request-Id: ilovepoop_*`, and `multipart/form-data` with WebKit boundaries.
3. Check for route probes against `/`, `/_next`, `/api`, `/_next/server`, `/app`, `/api/route`, `/_next/static/*`, `/_next/data/*`, `/.next/`, and `/_next/flight`.
4. Confirm whether any internet-facing Next.js / React Server Components application was exposed during the window.
5. For provider-owned rows, identify whether the traffic maps to provider infrastructure, a customer/tenant, CGNAT, hosted application, or security tooling.

Requested feedback fields:

- Local hit confirmed? yes/no/unknown
- Asset owner type: provider/customer/tenant/dedicated org/unknown
- Application exposure confirmed? yes/no/unknown
- Patched/remediated? yes/no/unknown/date
- Evidence available for sharing? flow/log/pcap/header sample/none
- Safe-to-share aggregate outcome? yes/no

Thank you,
WXA IASC

For coordination with WXA IASC: **iasc@whoisxmlapi.com**
