# WXA IASC LAC React2Shell Partner Package

This package supports partner and CSIRT validation of React2Shell / ILOVEPOOP exploit-scanning visibility across Latin America and the Caribbean.

## Suggested reading path

1. Start with the interactive briefing in `briefing/index.html` for the narrative flow.
2. Use `reports/` for the partner-facing intelligence brief and notification template.
3. Use `sector_narratives/` for healthcare, banking, Colombia, and broader critical-industry framing.
4. Use `data/` and `iocs/` for validation queues, hunting selectors, and local telemetry checks.

## Evidence posture

The NetFlow-derived interactions and advisory-collision views are validation leads. They are not proof of successful exploitation, compromise, data access, or victim status without local telemetry confirmation.

## Coordination

For partner coordination, contact **iasc@whoisxmlapi.com**.
