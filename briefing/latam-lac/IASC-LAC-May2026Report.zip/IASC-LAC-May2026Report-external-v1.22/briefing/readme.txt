WXA IASC LAC Partner Briefing

Open index.html in a browser. The briefing is static and loads local assets from ./assets and ./content.

Recommended flow: Proof, Victimology, LAC, Visibility, Research, Stories, Exchange, Delivery, Pathway.

Contact: iasc@whoisxmlapi.com
