window.IASC_VISIBILITY_DATA = {
  "proofWall": [
    {
      "id": "scale",
      "size": "normal",
      "eyebrow": "Global visibility",
      "title": "IASC turns partner signal into validation-ready evidence and coordinated action.",
      "stat": "multi-layer",
      "statLabel": "traffic, DNS, honeypots, feeds, partners",
      "detail": "The collective model combines partner-submitted signal with sampled traffic, passive DNS, honeypots, community feeds, WXA enrichment, and a broader task-force bench so CSIRTs and trusted partners can validate before they escalate.",
      "chips": [
        "sampled NetFlow",
        "passive DNS",
        "Niihama honeypots",
        "community feeds"
      ]
    },
    {
      "id": "lac",
      "size": "normal",
      "eyebrow": "PONAL / ColCERT advisories",
      "title": "WXA traffic overlapped with infrastructure described in recent PONAL and ColCERT advisories.",
      "stat": "35,686",
      "statLabel": "exact IP:port overlaps in WXA visibility",
      "detail": "WXA observed 35,686 exact IP:port overlaps tied to infrastructure also referenced in the advisories, alongside 444K+ matched flow rows and 6,086 unique Colombia peer IPs. This is visibility overlap only: shared infrastructure seen in traffic, not a partnership or victim claim.",
      "chips": [
        "35,686 exact overlaps",
        "444K+ matched records",
        "6,086 CO peer IPs",
        "visibility overlap only"
      ],
      "metaMetrics": [
        {
          "value": "444K+",
          "label": "matched flow rows"
        },
        {
          "value": "6,086",
          "label": "unique CO peer IPs"
        }
      ]
    },
    {
      "id": "salud",
      "size": "normal",
      "eyebrow": "CSIRT Salud advisories",
      "title": "WXA traffic also overlapped with infrastructure referenced in CSIRT Salud advisories.",
      "stat": "24,421",
      "statLabel": "flow records colliding with advisory infrastructure",
      "detail": "WXA saw 24,421 collided flow records across 13 of 19 advisory IPs, surfacing 3,459 unique peer IPs. This is visibility overlap only: advisory-linked infrastructure appearing in traffic, not a partnership claim or a direct compromise assertion.",
      "chips": [
        "24,421 collided records",
        "13 of 19 advisory IPs",
        "3,459 peer IPs",
        "visibility overlap only"
      ],
      "metaMetrics": [
        {
          "value": "13 / 19",
          "label": "advisory IPs observed"
        },
        {
          "value": "3,459",
          "label": "unique peer IPs"
        }
      ]
    },
    {
      "id": "react",
      "size": "normal",
      "eyebrow": "React2Shell research",
      "title": "Two major exploit servers aggressively probed 14M+ unique IPs.",
      "stat": "14M+",
      "statLabel": "unique IPs probed by two exploit servers",
      "detail": "The strongest React2Shell story is the scale of probing: two core exploit servers drove aggressive reconnaissance across more than 14 million unique IPs, with WXA IASC correlating NetFlow, honeypot behavior, Attaxion ownership enrichment, and external reporting into a target-exposure narrative.",
      "chips": [
        "two exploit servers",
        "14M+ IPs",
        "state-linked tooling",
        "target exposure"
      ]
    },
    {
      "id": "lac-r2s",
      "size": "normal",
      "eyebrow": "Latin America & Caribbean Probing",
      "title": "Same ILOVEPOOP exploit-scanning infrastructure produced 158K+ regional observations.",
      "stat": "158K+",
      "statLabel": "LAC/LATAM source-side probe observations",
      "detail": "The same nation-state attackers who leveraged the ILOVEPOOP toolkit had aggressive scanner interactions across LAC/LATAM netnames. The 158K+ regional observations suggest reconnaissance pressure that could precede future state-directed activity against probed targets, while remaining validation leads rather than proof of compromise.",
      "chips": [
        "Colombia",
        "banking",
        "healthcare",
        "critical industries"
      ]
    }
  ],
  "partnerRibbon": [],
  "visibilityLayers": [
    {
      "value": "multi-EB",
      "title": "Sampled NetFlow visibility",
      "detail": "Shows which systems interact with known exploit, C2, malware, scanner, or abuse infrastructure.",
      "source": "traffic layer"
    },
    {
      "value": "B/day",
      "title": "Passive DNS queries",
      "detail": "Adds domain-to-infrastructure history, timing, pivots, and resolver demand around suspicious names.",
      "source": "DNS layer"
    },
    {
      "value": "400+",
      "title": "Honeypot intelligence points",
      "detail": "Captures hostile behavior such as credential abuse, commands, protocol metadata, and attacker fingerprints.",
      "source": "Niihama layer"
    },
    {
      "value": "18",
      "title": "Protocol environments",
      "detail": "Enterprise services plus ICS/OT emulation including Modbus, BACnet, and DNP3.",
      "source": "behavior layer"
    },
    {
      "value": "EW",
      "title": "Early Warning Phishing Feed",
      "detail": "Proactive phishing-domain intelligence for partner detection and blocking workflows.",
      "source": "community feed"
    },
    {
      "value": "DGA",
      "title": "Early Warning DGA Feed",
      "detail": "DGA-oriented signals that help surface suspicious domain activity earlier.",
      "source": "community feed"
    },
    {
      "value": "TYPO",
      "title": "Typosquatting Community Feed",
      "detail": "Lookalike-domain visibility for fraud, phishing, brand, and abuse desk workflows.",
      "source": "community feed"
    },
    {
      "value": "joint",
      "title": "Research contributions",
      "detail": "Partners contribute indicators, validation, analyst time, regional context, and local outcomes.",
      "source": "collaboration"
    }
  ],
  "lacPackages": [
    {
      "id": "colombia",
      "name": "CSIRT-Ponal & ColCERT Advisory Collisions",
      "captionTitle": "PONAL / ColCERT advisory-collision visibility",
      "caption": "WXA traffic overlapped with infrastructure described in recent PONAL and ColCERT advisories; this is visibility overlap, not a partnership assertion.",
      "metrics": [
        {
          "label": "Matched flow rows",
          "value": "444K+",
          "tone": "blue"
        },
        {
          "label": "Colombia peer flows",
          "value": "173K+",
          "tone": "green"
        },
        {
          "label": "Exact IP:port matches",
          "value": "35,686",
          "tone": "amber"
        },
        {
          "label": "Unique CO peer IPs",
          "value": "6,086",
          "tone": "violet"
        }
      ],
      "pointTitle": "What the overlap shows",
      "point": "The overlap separates 35,686 exact IP:port matches from the larger 444K+ matched-flow context and highlights 6,086 unique Colombia peer IPs for validation-first outreach.",
      "storyTitle": "What the PONAL / ColCERT overlap shows",
      "narrative": "This package focuses on where WXA traffic overlapped with infrastructure described in recent PONAL and ColCERT advisories. The practical value is the overlap itself: 35,686 exact IP:port matches, 444K+ matched flow rows, and 6,086 unique Colombia peer IPs that can be prioritized for careful validation. It is a visibility lens, not a partnership or victim claim.",
      "meaning": [
        {
          "title": "Exact overlaps",
          "detail": "35,686 exact IP:port matches are the cleanest first queue."
        },
        {
          "title": "Traffic volume",
          "detail": "444K+ matched flow rows show the broader traffic context around the same infrastructure."
        },
        {
          "title": "Peer visibility",
          "detail": "6,086 unique Colombia peer IPs show where responders can begin local validation."
        },
        {
          "title": "Caveat discipline",
          "detail": "Use the overlap as a validation lead, not as proof of compromise or partnership."
        }
      ],
      "threatBuckets": [
        {
          "source": "CSIRT-PONAL",
          "pattern": "Reported C2 malware infrastructure bucket",
          "family": "Multiple malware families",
          "flows": "407,586",
          "evidence": "high"
        },
        {
          "source": "BlindEagle / APT-C-36",
          "pattern": "DCRAT and Caminho campaign context",
          "family": "DCRAT / Caminho",
          "flows": "28,973",
          "evidence": "context"
        },
        {
          "source": "Augmented Marauder / Water Saci",
          "pattern": "LATAM banking malware infrastructure",
          "family": "Horabot / Casbaneiro / Metamorfo",
          "flows": "6,898",
          "evidence": "context"
        },
        {
          "source": "ColCERT",
          "pattern": "Phishing, RAT and infostealer context",
          "family": "EvilToken / Remcos / Snake KeyLogger",
          "flows": "117+",
          "evidence": "medium"
        },
        {
          "source": "LockBit 5.0",
          "pattern": "Ransomware extortion infrastructure",
          "family": "Ransomware",
          "flows": "1",
          "evidence": "context"
        }
      ]
    },
    {
      "id": "salud",
      "name": "CSIRT Salud advisory collisions",
      "captionTitle": "CSIRT Salud advisory-collision visibility",
      "caption": "Healthcare-relevant advisory infrastructure from CSIRT Salud overlapped with WXA traffic visibility and was translated into validation-first leads.",
      "metrics": [
        {
          "label": "Flow collisions",
          "value": "24,421",
          "tone": "blue"
        },
        {
          "label": "Observed advisory IPs",
          "value": "13 / 19",
          "tone": "green"
        },
        {
          "label": "Unique peer IPs",
          "value": "3,459",
          "tone": "amber"
        },
        {
          "label": "Peer netnames",
          "value": "90",
          "tone": "violet"
        }
      ],
      "pointTitle": "What the overlap shows",
      "point": "WXA observed 24,421 collided flow records across 13 of 19 advisory IPs and surfaced 3,459 unique peer IPs. The emphasis stays on validation-first overlap, not on overclaiming compromise.",
      "storyTitle": "What the CSIRT Salud overlap shows",
      "narrative": "This package focuses on where WXA traffic overlapped with infrastructure referenced in CSIRT Salud advisories. WXA observed 24,421 collided flow records, saw 13 of 19 advisory IPs in traffic, and surfaced 3,459 unique peer IPs for follow-up. It is a visibility-overlap lens for healthcare defenders, not a partnership claim or a direct victim assertion.",
      "meaning": [
        {
          "title": "Advisory IPs observed",
          "detail": "13 of 19 advisory IPs were seen in sampled flow visibility."
        },
        {
          "title": "Traffic volume",
          "detail": "24,421 collided flow records show how often the advisory infrastructure appeared."
        },
        {
          "title": "Peer visibility",
          "detail": "3,459 unique peer IPs provide a concrete validation queue."
        },
        {
          "title": "Caveat discipline",
          "detail": "Treat the overlap as a validation lead, not as proof of compromise."
        }
      ],
      "threatBuckets": [
        {
          "source": "Larva-26002",
          "pattern": "MS-SQL attacks deploying ICE Cloud scanner",
          "family": "ICE Cloud / Trigona / Mimic",
          "flows": "24,326",
          "evidence": "dominant"
        },
        {
          "source": "FortiGate exploitation",
          "pattern": "Compromised devices, active vulnerabilities, persistence",
          "family": "Fortinet edge exploitation",
          "flows": "53",
          "evidence": "validate"
        },
        {
          "source": "Storm-1175",
          "pattern": "High-tempo Medusa ransomware operations",
          "family": "Medusa / SimpleHelp C2",
          "flows": "19",
          "evidence": "validate"
        },
        {
          "source": "Interlock",
          "pattern": "Cisco Secure FMC exploitation context",
          "family": "Interlock ransomware",
          "flows": "19",
          "evidence": "validate"
        },
        {
          "source": "Gunra",
          "pattern": "Threat to state and healthcare entities",
          "family": "Conti-derived ransomware",
          "flows": "4",
          "evidence": "context"
        }
      ]
    },
    {
      "id": "lac-react2shell-ilovepoop",
      "name": "LAC REACT2SHELL EXPLOIT SCANNING - ILOVEPOOP TOOLKIT",
      "captionTitle": "Latin America & Caribbean Probing",
      "caption": "Aggressive React2Shell exploit-scanning interactions with LAC/LATAM netnames were re-bucketed for CSIRT validation and pre-attack reconnaissance awareness.",
      "metrics": [
        {
          "label": "LAC/LATAM netnames",
          "value": "1,389",
          "tone": "blue"
        },
        {
          "label": "Regional probe observations",
          "value": "158K",
          "tone": "green"
        },
        {
          "label": "Colombia netnames",
          "value": "173",
          "tone": "amber"
        },
        {
          "label": "Direct P1 critical leads",
          "value": "39",
          "tone": "violet"
        }
      ],
      "pointTitle": "The point of the regional probing pass",
      "point": "Turn LAC/LATAM source-netname counts around 193.142.147[.]209 and 87.121.84[.]24 into sector-aware CSIRT queues while keeping the caveat clear: scanner interaction suggests reconnaissance pressure, not confirmed compromise.",
      "storyTitle": "Latin America & Caribbean Probing",
      "narrative": "The same nation-state attackers who leveraged the ILOVEPOOP toolkit had 158K+ LAC/LATAM source-side probe observations across 1,389 in-scope netnames. That pattern suggests reconnaissance for possible future state-directed activity against probed targets. WXA IASC turns this into a validation queue for healthcare, banking, water, energy, education, industrial, telecom, and Colombia-focused responders rather than a public victim list.",
      "meaning": [
        {
          "title": "Sector-aware triage",
          "detail": "Healthcare, banking, utilities, telecom, cloud, education, industrial, and public-sector names are tagged separately."
        },
        {
          "title": "Colombia lane",
          "detail": "173 Colombia-focused netnames produced 11,108 source-side flow counts, split into direct critical-sector and provider validation lanes."
        },
        {
          "title": "Provider reality",
          "detail": "Most volume sits in telecom, ISP, cloud, and access-network names, where CSIRTs should request local logs or provider-side PCAP before naming victims."
        },
        {
          "title": "Caveat discipline",
          "detail": "Observed scanner interaction means exposure or communication evidence. It does not establish exploitation success, data access, or compromise."
        }
      ],
      "threatBuckets": [
        {
          "source": "Telecom / ISP provider lane",
          "pattern": "ETB, VTR, Telecom Argentina, Viettel Peru, Red Cientifica Peruana, UFINET, IFX, Telmex, Level 3/Cirion-style networks",
          "family": "provider-mediated validation",
          "flows": "94,114",
          "evidence": "dominant"
        },
        {
          "source": "Banking / financial lane",
          "pattern": "Banco do Nordeste, Banco de Chile, Banco do Brasil, Banco Macro, Bancolombia, Banco del Pacifico, Banco Guayaquil and related netnames",
          "family": "banking CSIRT validation",
          "flows": "2,570",
          "evidence": "P1/P2"
        },
        {
          "source": "Healthcare / life sciences lane",
          "pattern": "Oxigenos de Colombia, Health Prime, Unimed, Fresenius, Saludsa, Novo Nordisk, AGFA Healthcare and healthcare-support names",
          "family": "healthcare CSIRT validation",
          "flows": "51",
          "evidence": "sensitive"
        },
        {
          "source": "Energy / water / industrial lane",
          "pattern": "Oil/gas, electric cooperatives, water authorities, manufacturing and industrial suppliers including Oleoducto Bicentenario, Acueducto de Bogota and Emerald Energy",
          "family": "critical-industry validation",
          "flows": "584",
          "evidence": "critical"
        },
        {
          "source": "CSIRT-Ponal & ColCERT advisory-collision queue",
          "pattern": "173 Colombia-focused netnames with direct critical-sector leads and provider/sector validation leads",
          "family": "national and sectoral validation",
          "flows": "11,108",
          "evidence": "actionable"
        }
      ]
    }
  ],
  "cases": [
    {
      "id": "lac",
      "label": "PONAL / ColCERT advisories",
      "title": "CSIRT-Ponal & ColCERT Advisory Collisions",
      "subtitle": "Advisory infrastructure overlap seen in WXA traffic",
      "headlineMetric": "35,686",
      "headlineLabel": "exact IP:port overlaps tied to PONAL / ColCERT advisory infrastructure",
      "narrative": "This proof path focuses only on overlap between WXA traffic visibility and infrastructure described in recent PONAL / ColCERT advisories. WXA observed 35,686 exact IP:port overlaps, 444K+ matched flow rows, and 6,086 unique Colombia peer IPs that can be prioritized for validation-first follow-up.",
      "points": [
        "35,686 exact IP:port overlaps were observed in WXA visibility",
        "444K+ matched flow rows show the broader traffic context",
        "6,086 unique Colombia peer IPs were surfaced for follow-up",
        "Use the overlap as a validation queue, not a partnership claim",
        "Infrastructure overlap is a lead for outreach, not proof of compromise",
        "Feedback from responders can refine the next package"
      ]
    },
    {
      "id": "salud",
      "label": "CSIRT Salud",
      "title": "CSIRT Salud advisory collision analysis",
      "subtitle": "Advisory infrastructure overlap in healthcare-relevant traffic",
      "headlineMetric": "24,421",
      "headlineLabel": "flow records colliding with CSIRT Salud advisory infrastructure",
      "narrative": "This proof path focuses on overlap between WXA traffic and infrastructure referenced in CSIRT Salud advisories. WXA observed 24,421 collided flow records, saw 13 of 19 advisory IPs, and surfaced 3,459 unique peer IPs for validation-first follow-up.",
      "points": [
        "24,421 collided flow records were observed",
        "13 of 19 advisory IPs appeared in sampled traffic",
        "3,459 unique peer IPs were surfaced",
        "The overlap is useful for validation, not for overclaiming compromise",
        "Healthcare responders can start with peer IPs, netnames, and timestamps",
        "The package stays visibility-first and caveat-disciplined"
      ]
    },
    {
      "id": "react2shell",
      "label": "React2Shell",
      "title": "To Cache a Predator",
      "subtitle": "React2Shell and ILOVEPOOP toolkit discovery",
      "headlineMetric": "14M+",
      "headlineLabel": "unique IPs aggressively probed by two exploit servers",
      "narrative": "WXA IASC correlated two major exploit servers with aggressive probing of more than 14 million unique IPs, then used NetFlow-derived telemetry, honeypot observations, U.S. exposure enrichment, Attaxion ownership analysis, and outside reporting to turn raw exploit scanning into a concrete target-exposure story.",
      "points": [
        "Two Netherlands-hosted exploit servers anchored the global traffic analysis",
        "More than 14 million unique IPs were aggressively probed",
        "The surrounding NetFlow set included 22.3M records around the two core nodes",
        "ILOVEPOOP generated 672 exploit attempts across nine scanner nodes",
        "U.S. destination pressure reached 5.33M flows for victimology enrichment",
        "Brazil and wider LAC pressure highlighted banking, government, energy, utilities, and developer assets"
      ]
    },
    {
      "id": "lac-react2shell-ilovepoop",
      "label": "LAC REACT2SHELL EXPLOIT SCANNING - ILOVEPOOP TOOLKIT",
      "title": "Latin America & Caribbean Probing",
      "subtitle": "Exploit-scanning visibility for CSIRT action",
      "headlineMetric": "158K+",
      "headlineLabel": "LAC/LATAM source-side probe observations",
      "narrative": "WXA IASC extended the React2Shell/ILOVEPOOP work into a Latin America & Caribbean probing pass. The same nation-state attackers who leveraged ILOVEPOOP exploit scanning showed 158K+ regional observations across 1,389 LAC/LATAM netnames. That pattern suggests pre-attack reconnaissance pressure and gives CSIRTs a way to request the right logs without overclaiming compromise.",
      "points": [
        "158,093 LAC/LATAM source-side probe observations across 1,389 in-scope netnames",
        "173 Colombia-focused netnames and 11,108 Colombia observations",
        "54 banking/financial rows and 2,570 observations for sectoral validation",
        "13 healthcare/life-sciences rows with low-volume but high-sensitivity validation value",
        "393 broader critical-industry rows, dominated by telecom/ISP and provider-mediated validation",
        "Every lead remains evidence for local validation, not proof of successful exploitation"
      ]
    },
    {
      "id": "niihama",
      "label": "Niihama",
      "title": "Global honeypot threat intelligence",
      "subtitle": "Behavior, not just reputation",
      "headlineMetric": "400+",
      "headlineLabel": "active intelligence points",
      "narrative": "Niihama adds behavior to infrastructure intelligence by emulating enterprise and ICS/OT services and capturing protocol-specific attacker activity, credential abuse, commands, fingerprints, and threat scores.",
      "points": [
        "18 emulated protocol environments",
        "Global regional sensor grid",
        "Enterprise and cloud protocols plus ICS/OT protocols",
        "IP profiles and threat scoring",
        "Credential intelligence and brute-force summaries",
        "API-first delivery for SOC and MSSP workflows"
      ]
    },
    {
      "id": "icann",
      "label": "ICANN-supported DNS abuse",
      "title": "Making sense of DNS abuse in gTLDs",
      "subtitle": "Large-scale abuse analysis",
      "headlineMetric": "193M+",
      "headlineLabel": "domains mapped to WHOIS records",
      "narrative": "ICANN-supported research used WXA WHOIS data to study DNS abuse in legacy and new gTLDs, bringing registrar and registration-date context to blacklist-driven abuse analysis.",
      "points": [
        "1,190+ TLDs analyzed",
        "193M+ domain names studied",
        "11 reputable blacklists were used in the research approach",
        "WHOIS context enabled registrar and creation-date analysis",
        "Research helped explore malicious registration behavior",
        "Shows WXA data value for governance and measurement"
      ]
    },
    {
      "id": "hackerone",
      "label": "HackerOne",
      "title": "Ethical hacking community enablement",
      "subtitle": "Infrastructure intelligence for better assessments",
      "headlineMetric": "7",
      "headlineLabel": "WXA APIs in use",
      "narrative": "HackerOne\u2019s ethical hacking community benefits from reliable domain, DNS, WHOIS, historical WHOIS, subdomain, and IP intelligence that reduces blind spots and false positives during security assessments.",
      "points": [
        "Improves target infrastructure discovery",
        "Speeds up vulnerability analysis",
        "Helps hackers validate domains and ownership context",
        "Supports detailed reporting to target organizations",
        "Reduces time spent collecting fragmented DNS and WHOIS data",
        "Empowers trusted security communities"
      ]
    },
    {
      "id": "whodat",
      "label": "MITRE WhoDat",
      "title": "WHOIS pivots for adversary infrastructure",
      "subtitle": "Research tooling and analyst workflows",
      "headlineMetric": "WHOIS",
      "headlineLabel": "pivotable intelligence",
      "narrative": "MITRE\u2019s WhoDat / PyDat project shows how current and historical WHOIS, DNS, and IP resolution data can support adversary infrastructure analysis, including spear-phishing link-domain pivots.",
      "points": [
        "Integrates WHOIS data, current IP resolutions, and DNS Database",
        "Supports scriptable JSON queries",
        "Built for flexible analyst workflows",
        "Demonstrates WHOIS pivoting for spear-phishing infrastructure",
        "Open-source tooling brings intelligence to the community",
        "Turns domain clues into broader infrastructure context"
      ]
    },
    {
      "id": "disinfo",
      "label": "EU DisinfoLab",
      "title": "Historical WHOIS for disinformation investigations",
      "subtitle": "Indian Chronicles",
      "headlineMetric": "15-year",
      "headlineLabel": "disinformation operation exposed",
      "narrative": "EU DisinfoLab used historical WHOIS footprints to support an investigation into Indian Chronicles, a long-running disinformation operation involving domains, fake media outlets, and impersonation of NGOs and personalities.",
      "points": [
        "Investigation relied heavily on website and domain analysis",
        "Historical registration data helped uncover links",
        "Domains were central to understanding the operation",
        "WHOIS footprints supported contextualization",
        "Shows domain data value beyond malware and phishing",
        "Highlights transparency as a defense mechanism"
      ]
    },
    {
      "id": "danish",
      "label": "Danish Broadcast",
      "title": "Exposing who is behind harmful web properties",
      "subtitle": "Human trafficking investigation support",
      "headlineMetric": "2,000+",
      "headlineLabel": "registrants possibly connected",
      "narrative": "A Danish Broadcast investigation used historical Reverse WHOIS in Maltego to map domains tied to phone numbers and email addresses found on suspicious recruitment ads.",
      "points": [
        "34 brothels surfaced with specific indicators of human trafficking",
        "2,000+ registrants were mapped as potentially connected",
        "Phone numbers and emails became WHOIS pivots",
        "Historical WHOIS revealed changing registrants over time",
        "Structured data reduced manual web searching",
        "Shows investigative value for public-interest work"
      ]
    },
    {
      "id": "ncptf",
      "label": "National Child Protection Task Force (NCPTF)",
      "title": "Helping stop human trafficking with OSINT intelligence",
      "subtitle": "Child-protection, human-trafficking, and missing-person investigations",
      "headlineMetric": "10B+",
      "headlineLabel": "historical WHOIS records available for pivots",
      "narrative": "WXA supports NCPTF by contributing domain, IP, DNS, and historical WHOIS intelligence that helps vetted investigators connect online indicators to trafficking, exploitation, and missing-person leads while keeping sensitive cases in trusted channels.",
      "points": [
        "Turns domains, IPs, registrants, and hosting pivots into leads for vetted investigators",
        "Supports rapid collaboration with law enforcement and trained volunteer OSINT teams",
        "Helps identify connected web properties that may advertise, coordinate, or enable exploitation",
        "Keeps sensitive human-safety cases inside responsible, need-to-know workflows",
        "Shows how internet infrastructure intelligence can help stop human trafficking",
        "Evidence supports rescue, disruption, and investigative prioritization rather than public victim naming"
      ]
    },
    {
      "id": "perugia",
      "label": "University of Perugia",
      "title": "Investigation training for law enforcement",
      "subtitle": "Repeatable investigation techniques",
      "headlineMetric": "LE",
      "headlineLabel": "training workflows",
      "narrative": "The University of Perugia used WXA data and Maltego transforms to teach investigation techniques involving historical WHOIS, Reverse WHOIS, Reverse IP, and domain/IP intelligence.",
      "points": [
        "Historical WHOIS restored visibility hidden by modern redaction",
        "Reverse IP helped identify domains hosted on an IP",
        "Maltego workflows made the techniques teachable",
        "Students and law-enforcement trainees gained practical pivots",
        "Improved ability to trace digital footprints",
        "Demonstrates repeatable investigative methodology"
      ]
    }
  ],
  "victimology": {
    "spokes": [
      "Commercial / enterprise",
      "Hosting / ISPs",
      "Government",
      "SaaS / software",
      "Retail / eCommerce",
      "Education / research",
      "Workforce / security",
      "Healthcare & life sciences",
      "Media & entertainment",
      "Financial services"
    ],
    "cards": [
      {
        "value": "14M+",
        "title": "Unique IPs aggressively probed",
        "detail": "Two core exploit servers drove the strongest React2Shell narrative: large-scale probing before enrichment narrowed the view into likely organizational exposure."
      },
      {
        "value": "65,821",
        "title": "High-identifiability records",
        "detail": "U.S.-sourced NetFlow records remained after filtering for likely attributable or dedicated asset ownership."
      },
      {
        "value": "3,420",
        "title": "Unique U.S. netnames",
        "detail": "Attaxion enrichment helped resolve which organizations likely owned the pressured IP space while reducing shared or multi-tenant noise."
      },
      {
        "value": "69.2%",
        "title": "Commercial & enterprise",
        "detail": "45,550 records mapped to commercial and enterprise organizations, making private-sector exposure the dominant story."
      },
      {
        "value": "18.2%",
        "title": "Hosting & internet infrastructure",
        "detail": "11,979 records still landed in provider or hosting footprints that may require an extra tenant-validation step."
      },
      {
        "value": "59.5%",
        "title": "SaaS / software platforms",
        "detail": "39,140 records clustered into SaaS and software platforms, the clearest micro-category concentration in the high-identifiability set."
      },
      {
        "value": "81.9%",
        "title": "Long-tail ownership",
        "detail": "81.9% of netnames had five or fewer records, showing broad but shallow exposure beyond the biggest names."
      }
    ],
    "regionBars": [
      {
        "label": "Commercial & enterprise organizations",
        "value": 45550,
        "display": "69.2%"
      },
      {
        "label": "Internet & hosting infrastructure providers",
        "value": 11979,
        "display": "18.2%"
      },
      {
        "label": "Government & public sector",
        "value": 7409,
        "display": "11.3%"
      },
      {
        "label": "Financial services",
        "value": 837,
        "display": "1.27%"
      },
      {
        "label": "Nonprofit",
        "value": 24,
        "display": "0.04%"
      },
      {
        "label": "Healthcare",
        "value": 22,
        "display": "0.03%"
      }
    ],
    "highlights": [
      {
        "label": "SaaS / software platforms",
        "display": "39,140 \u00b7 59.5%"
      },
      {
        "label": "Retail & eCommerce",
        "display": "4,091"
      },
      {
        "label": "Workforce management & security",
        "display": "2,977"
      },
      {
        "label": "Government agencies",
        "display": "2,918"
      },
      {
        "label": "ISP customer-assigned address space",
        "display": "2,715"
      },
      {
        "label": "Education & research institutions",
        "display": "2,644"
      },
      {
        "label": "Healthcare & life sciences",
        "display": "1,848"
      },
      {
        "label": "Media & entertainment",
        "display": "1,786"
      },
      {
        "label": "Email security platforms",
        "display": "1,677"
      },
      {
        "label": "Energy & utilities",
        "display": "1,435"
      }
    ]
  },
  "packageParts": [
    {
      "title": "Orient",
      "detail": "Executive narrative, evidence caveat, scope, and why the signal matters now."
    },
    {
      "title": "Prioritize",
      "detail": "High-confidence triage subset plus sector, country, source-type, ASN, peer, and netname summaries."
    },
    {
      "title": "Validate",
      "detail": "CSV exports, IOCs, ownership context, network lead cards, and local-confirmation questions."
    },
    {
      "title": "Coordinate",
      "detail": "Notification language, escalation constraints, and feedback fields for confirmed hits and false positives."
    }
  ],
  "packageStack": [
    "Observed signal: exploit servers, advisory collisions, regional probes, or partner-submitted leads",
    "Context layer: sampled traffic, passive DNS, honeypots, WXA enrichment, and prior cases",
    "Triage layer: high-confidence rows separated from contextual pivots and provider-mediated noise",
    "Action layer: validation questions, outreach language, escalation limits, and feedback loop"
  ],
  "sharedInfra": {
    "risky": [
      "Assume a peer collision means compromise",
      "Treat shared infrastructure as IP-only evidence",
      "Ignore missing exact IP:port matches",
      "Send broad accusations to network owners",
      "Skip local telemetry validation"
    ],
    "safer": [
      "Use exact IP:port, timestamp, peer IP, ASN and netname evidence",
      "Validate DNS, SNI, HTTP Host, URI and endpoint process context",
      "Separate high-confidence rows from contextual pivots",
      "Ask for local validation before escalation",
      "Feed confirmed outcomes or false positives back into IASC"
    ]
  },
  "pathway": [
    {
      "title": "See one relevant package",
      "detail": "Start with a focused package, feed, API output, or CSV export tied to the partner's region, sector, mission, or current incident pressure."
    },
    {
      "title": "Validate in local telemetry",
      "detail": "Use DNS, proxy, firewall, WAF, EDR, ownership, provider, and application logs to confirm what is real before escalation."
    },
    {
      "title": "Return outcomes",
      "detail": "Share confirmed hits, false positives, local sightings, new IoCs, and telemetry-quality notes so the next package becomes sharper."
    },
    {
      "title": "Set cadence and boundaries",
      "detail": "Align signal type, schema, sharing limits, attribution, redistribution, access, and participation tier once recurring value is clear."
    }
  ],
  "logoWall": [
    {
      "name": "Trusted Notifier Network",
      "mark": "TNN",
      "role": "Trusted abuse escalation and notifier collaboration",
      "tone": "blue",
      "asset": "trusted-notifier-network.webp",
      "logoShape": "wide"
    },
    {
      "name": "Sequretek",
      "mark": "SQ",
      "role": "Security operations and telemetry collaboration",
      "tone": "green",
      "asset": "sequretek.png",
      "logoShape": "wide"
    },
    {
      "name": "Attaxion",
      "mark": "ATX",
      "role": "Exposure management and external-asset visibility",
      "tone": "violet",
      "asset": "attaxion.png",
      "logoShape": "wide"
    },
    {
      "name": "ICANN-supported research",
      "mark": "ICANN",
      "role": "DNS abuse measurement and governance research",
      "tone": "blue",
      "asset": "icann.png",
      "logoShape": "square"
    },
    {
      "name": "MITRE WhoDat",
      "mark": "MITRE",
      "role": "WHOIS and DNS pivot tooling for analyst workflows",
      "tone": "green",
      "asset": "mitre.png",
      "logoShape": "wide"
    },
    {
      "name": "EU DisinfoLab",
      "mark": "EUD",
      "role": "Disinformation research and public-interest analysis",
      "tone": "blue",
      "asset": "eu-disinfolab.png",
      "logoShape": "wide"
    },
    {
      "name": "Danish Broadcasting",
      "mark": "DR",
      "role": "Human-trafficking investigation support with domain pivots",
      "tone": "amber",
      "asset": "danish-broadcasting.jpg",
      "darkLogo": true,
      "logoShape": "wide"
    },
    {
      "name": "National Child Protection Task Force (NCPTF)",
      "mark": "NCPTF",
      "role": "OSINT and intelligence support to combat online child exploitation",
      "tone": "red",
      "asset": "national-child-protection-task-force.png",
      "darkLogo": true,
      "logoShape": "wide"
    }
  ],
  "benefitPrinciples": [
    {
      "title": "Usefulness first",
      "detail": "Access grows when signal repeatedly improves validation, early warning, or CSIRT response."
    },
    {
      "title": "Fidelity over volume",
      "detail": "Provenance, timestamps, confidence, and repeatability matter more than raw record count."
    },
    {
      "title": "Boundaries before outreach",
      "detail": "Privacy, attribution, redistribution, and escalation rules are agreed before action."
    },
    {
      "title": "Feedback strengthens the bench",
      "detail": "Confirmed hits, misses, and local context sharpen future packages for the whole collective."
    }
  ],
  "partnerTiers": [
    {
      "tier": "Tier 3",
      "name": "Open Signal Contributor",
      "bestFor": "First proof of value: confirmed indicators, niche abuse observations, scan output, or limited sensor support.",
      "contributes": "Confirmed IoCs, pivots, phishing domains, scan outputs, abuse indicators, or limited sensor capacity with provenance.",
      "gets": [
        "20,000 DRS credits/month",
        "50 Niihama API queries/day",
        "Weekly Niihama IoC exports",
        "Early Warning Phishing + DGA feeds",
        "Discount eligibility for qualifying enterprise data licenses"
      ],
      "posture": "Best for testing fit before a recurring telemetry commitment."
    },
    {
      "tier": "Tier 2",
      "name": "Telemetry Partner",
      "bestFor": "Recurring validation: predictable telemetry or operational observations for SOC, CSIRT, or MSSP workflows.",
      "contributes": "Telemetry with schema clarity, cadence, retention or replay expectations, quality notes, and privacy-aware handling.",
      "gets": [
        "100,000 DRS credits/month",
        "500 Niihama API queries/day",
        "Daily Niihama exports",
        "First Watch + Typosquatting Community Feed",
        "Enhanced WXA Joint Research / PR support when mutually approved"
      ],
      "posture": "Best for recurring intelligence, stronger enrichment, feed access, and qualified detection collaboration."
    },
    {
      "tier": "Tier 1",
      "name": "Strategic Signal Partner",
      "bestFor": "Strategic coverage: large-scale or hard-to-observe visibility that materially improves regional response or research.",
      "contributes": "High-scale telemetry or unique vantage points across geographies, DNS/flow/TLS/HTTP, ICS, or rapid-response signal.",
      "gets": [
        "500,000 DRS credits/month",
        "1,000 Niihama API queries/day",
        "Priority enrichment and validation",
        "Larger strategic discounts; OSINT discounts case by case",
        "Priority research support + strategic roadmap input"
      ],
      "posture": "Best for priority validation, strategic collaboration, and mutually approved research or response support."
    }
  ],
  "contributionSignals": [
    {
      "signal": "Confirmed indicators",
      "examples": "Domains, URLs, hashes, C2 IPs, phishing kits, JA4/TLS features, wallet abuse, and tagged confidence/provenance."
    },
    {
      "signal": "Passive telemetry",
      "examples": "NetFlow or equivalent flows, DNS telemetry, HTTP/WAF/proxy events, TLS handshake features, and browser/device features when policy allows."
    },
    {
      "signal": "Strategic vantage points",
      "examples": "Hard-to-observe regions, large-scale resolver or hosting views, ICS/OT visibility, or first-wave exploitation pressure."
    },
    {
      "signal": "Sensor support",
      "examples": "Sublet hosting, compute, network capacity, honeypot/sensor placement, and structured internet measurement outputs."
    }
  ],
  "onboardingChecks": [
    "Signal type",
    "Volume + cadence",
    "Schema + transport",
    "Provenance + confidence",
    "Retention + replay",
    "Privacy/legal limits",
    "Redistribution + attribution",
    "Escalation path"
  ],
  "externalStories": {
    "ilovepoop": [
      {
        "source": "BankInfoSecurity",
        "logo": "bankinfosecurity.svg",
        "title": "Nation-State and Cybercrime Exploits Tied to React2Shell",
        "titleEs": "Exploits de React2Shell vinculados con actores estatales y ciberdelito",
        "summary": "Independent coverage framed React2Shell as activity relevant to both nation-state and cybercrime operators, reinforcing that the campaign deserved attention beyond opportunistic scanning.",
        "summaryEs": "La cobertura independiente present\u00f3 React2Shell como una actividad relevante tanto para operadores estatales como del ciberdelito, reforzando que la campa\u00f1a merec\u00eda atenci\u00f3n m\u00e1s all\u00e1 del escaneo oportunista.",
        "findings": [
          "Places React2Shell inside a broader nation-state and cybercrime threat context",
          "Provides useful outside corroboration that the campaign warranted serious attribution attention"
        ],
        "findingsEs": [
          "Ubica a React2Shell dentro de un contexto m\u00e1s amplio de amenazas estatales y de ciberdelito",
          "Aporta corroboraci\u00f3n externa \u00fatil de que la campa\u00f1a merec\u00eda atenci\u00f3n seria de atribuci\u00f3n"
        ],
        "url": "https://www.bankinfosecurity.com/nation-state-cybercrime-exploits-tied-to-react2shell-a-30285"
      },
      {
        "source": "Red Hot Cyber",
        "logo": "red-hot-cyber.svg",
        "title": "State-Sponsored \"ILovePoop\" Toolkit Targets Global Giants via React2Shell Vulnerability",
        "titleEs": "El toolkit \"ILovePoop\" con apoyo estatal apunta a gigantes globales mediante la vulnerabilidad React2Shell",
        "summary": "Red Hot Cyber cited the WhoisXML API analysis and extended the story with outside framing around the scale of likely exposure, recognizable victim organizations, and the broader campaign profile.",
        "summaryEs": "Red Hot Cyber cit\u00f3 el an\u00e1lisis de WhoisXML API y ampli\u00f3 la historia con un enfoque externo sobre la escala de la exposici\u00f3n probable, las organizaciones v\u00edctimas reconocibles y el perfil m\u00e1s amplio de la campa\u00f1a.",
        "findings": [
          "Highlights reporting that more than 37,000 networks were potentially in scope",
          "Names likely-targeted organizations such as NASA, DISA, Goldman Sachs, Netflix, and Disney, strengthening the bridge from raw exposure to external validation"
        ],
        "findingsEs": [
          "Destaca informes seg\u00fan los cuales m\u00e1s de 37.000 redes estuvieron potencialmente dentro del alcance",
          "Menciona organizaciones probablemente objetivo como NASA, DISA, Goldman Sachs, Netflix y Disney, reforzando el puente entre la exposici\u00f3n bruta y la validaci\u00f3n externa"
        ],
        "url": "https://www.redhotcyber.com/en/post/state-sponsored-ilovepoop-toolkit-targets-global-giants-via-react2shell-vulnerability/"
      }
    ],
    "proof": [
      {
        "source": "OSINord",
        "logo": "osinord.svg",
        "title": "The Mystery of Nadia Marcinko: Epstein\u2019s Alleged Right Hand and Her Digital Trail",
        "titleEs": "El misterio de Nadia Marcinko: la presunta mano derecha de Epstein y su rastro digital",
        "summary": "OSINord\u2019s investigation explicitly notes WhoisXML API as one of the tools used to analyze historical registrant information linked to domains associated with Marcinko.",
        "summaryEs": "La investigaci\u00f3n de OSINord se\u00f1ala expl\u00edcitamente a WhoisXML API como una de las herramientas utilizadas para analizar informaci\u00f3n hist\u00f3rica de registrantes vinculada a dominios asociados con Marcinko.",
        "findings": [
          "Shows domain and historical registrant analysis supporting public-interest investigations",
          "Provides a concrete example of third-party investigative teams using WhoisXML API in a broader digital-trail workflow"
        ],
        "findingsEs": [
          "Muestra c\u00f3mo el an\u00e1lisis de dominios e historial de registrantes apoya investigaciones de inter\u00e9s p\u00fablico",
          "Ofrece un ejemplo concreto de equipos investigadores externos que usan WhoisXML API dentro de un flujo m\u00e1s amplio de rastreo digital"
        ],
        "url": "https://www.osinord.com/post/the-mystery-of-nadia-marcinko-epstein-s-alleged-right-hand-and-her-digital-trail"
      },
      {
        "source": "SecurityBrief",
        "logo": "securitybrief.svg",
        "title": "Counterfeiters targeted Eli Lilly pill before launch",
        "titleEs": "Falsificadores apuntaron al medicamento de Eli Lilly antes de su lanzamiento",
        "summary": "SecurityBrief reported on WhoisXML API research showing how public WHOIS and pre-launch domain activity enabled counterfeiters to prepare convincing pharmacy-style scams before a product launch.",
        "summaryEs": "SecurityBrief inform\u00f3 sobre una investigaci\u00f3n de WhoisXML API que mostr\u00f3 c\u00f3mo el WHOIS p\u00fablico y la actividad de dominios previa al lanzamiento permitieron a falsificadores preparar estafas convincentes de estilo farmacia antes del lanzamiento de un producto.",
        "findings": [
          "Uses a concrete Eli Lilly case to show the business risk created by exposed pre-launch naming signals",
          "Extends the narrative from threat research into brand protection, fraud prevention, and domain monitoring"
        ],
        "findingsEs": [
          "Utiliza un caso concreto de Eli Lilly para mostrar el riesgo de negocio creado por se\u00f1ales de nombres expuestos antes del lanzamiento",
          "Extiende la narrativa desde la investigaci\u00f3n de amenazas hacia protecci\u00f3n de marca, prevenci\u00f3n de fraude y monitoreo de dominios"
        ],
        "url": "https://securitybrief.news/story/counterfeiters-targeted-eli-lilly-pill-before-launch"
      }
    ]
  }
};
