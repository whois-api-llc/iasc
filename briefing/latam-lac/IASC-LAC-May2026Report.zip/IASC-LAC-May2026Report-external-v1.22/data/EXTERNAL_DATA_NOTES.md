# External data notes

This external package includes curated validation queues only. The queues are designed for CSIRT/SOC validation and outreach. They should not be treated as confirmed compromise, victim status, or data-access evidence without local telemetry validation.

Narrative note: present the LAC append as Latin America & Caribbean probing, with 158K+ regional source-side probe observations that suggest reconnaissance pressure and require local validation.
