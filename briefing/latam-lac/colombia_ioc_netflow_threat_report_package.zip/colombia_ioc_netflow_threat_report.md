# Colombia-focused IOC NetFlow Match Analysis

**Prepared from uploaded files:** `results(2).csv` and `latam_colombia_network_iocs_2025Q4_2026Q2.csv`  
**Flow window:** 2025-11-08 00:11:17 to 2026-05-06 01:50:14  
**Report focus:** network IOC matches useful to local CERT-style response teams.

## Executive summary

The uploaded flow file is a pre-filtered match set: **444,157 of 444,157 records** had either source or destination IP equal to an IP IOC in the comprehensive IOC CSV. The IOC CSV contained **119 unique IP indicators**, of which **91** appeared in the flows and **28** did not.

The strongest Colombia lead is a high-volume cluster of P1 CSIRT-PONAL IP IOCs. **Colombia was the largest non-IOC peer country by flow count**, with **173,704 flows** and **6,086 unique non-IOC peer IPs**. Most Colombian exposure is concentrated in large access networks and ISPs, especially Colombia Móvil, Telmex Colombia, UNE EPM, ETB, and other connectivity providers. This pattern is consistent with broad endpoint exposure across consumer, mobile, and enterprise access networks, but the data alone does not prove host compromise.

Directionally, the IOC was the destination in **372,809 flows** and the source in **71,344 flows** when exactly one endpoint was an IOC. **35,686 flows** matched an IP plus a port explicitly present in the IOC CSV, which should be treated as a higher-confidence triage subset.

## Key metrics

|Metric|Value|
|---|---|
|Flow records processed|444,157|
|Flow records matching IOC IPs|444,157|
|Unique IP IOCs in IOC CSV|119|
|Observed IOC IPs|91|
|Unobserved IOC IPs|28|
|Unique non-IOC peer IPs|27,405|
|Colombia peer flows|173,704|
|Unique Colombia peer IPs|6,086|
|Exact IOC IP:port flow matches|35,686|
|Total in_bytes field|246.0 MiB|
|TCP / UDP / ICMP / GRE|357,120 / 82,841 / 4,194 / 2|

## Top IOC IPs by matched flows

|IOC IP|Flows|Unique peers|Priority|Actor or cluster|Family or tooling|Top peer countries|
|---|---|---|---|---|---|---|
|45.83.31.95|81,701|2,334|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|CO:72589; NA:5046; US:1634; ES:1197; NL:239; ZZ:188; GB:154; CA:136|
|38.96.254.100|49,557|357|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|US:43692; SG:2672; EU:1744; IN:530; NA:504; CL:156; HK:140; CA:85|
|193.26.115.189|37,895|2,337|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|DE:19646; CO:12418; US:3597; GB:625; NA:428; CA:367; NL:119; PT:62|
|45.88.186.31|36,253|2,438|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|CO:19612; US:7513; RU:5063; GB:1277; NL:690; IE:512; NA:445; CA:258|
|45.83.31.136|25,503|2,270|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|CO:21157; US:1342; NA:518; NL:499; DE:410; RU:341; GB:194; PA:183|
|158.94.209.58|24,313|1,310|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|US:15549; IT:2404; JP:2379; BE:835; AU:829; GB:757; SI:272; IN:214|
|45.83.31.12|24,157|1,581|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|CO:10578; FI:9020; US:1895; GB:601; BD:298; NL:288; BR:242; DE:210|
|158.94.208.109|20,908|4,542|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|JP:20372; BR:148; US:122; IN:98; CO:32; DE:27; NL:27; SG:26|
|193.26.115.161|20,903|1,264|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|CO:15501; NA:1867; US:1553; KR:540; DE:307; NL:184; EU:145; GB:122|
|45.92.16.135|15,205|285|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|US:12952; EU:868; IN:757; NA:379; NL:73; SG:50; CA:47; HK:25|
|45.83.31.35|14,948|1,393|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|CO:7723; US:3398; PA:1004; GB:763; NL:487; NA:385; BR:242; DE:111|
|45.153.34.67|14,217|1,615|P2|BlindEagle / APT-C-36|DCRAT|CO:5971; BR:1868; US:1408; AR:1384; EC:399; TR:374; IN:361; CN:330|
|45.83.31.114|12,098|1,261|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|US:4563; CO:3239; NL:1896; BR:368; GB:231; ZA:223; EU:213; FR:187|
|45.133.180.146|11,232|140|P1|Multiple malware operators reported by CSIRT-PONAL|Malware C2, multiple families|US:10572; IN:321; EU:163; NA:100; HK:53; CA:9; NL:4; DE:4|
|146.70.215.50|9,168|320|P2|BlindEagle / APT-C-36|DCRAT|US:5445; HK:1522; IN:1093; EU:783; FR:91; NL:80; IR:36; NA:34|

## Colombian peer networks

|ASN|AS name|Flows|Unique peer IPs|IOC IPs touched|Top IOC IPs|
|---|---|---|---|---|---|
|AS27831|Colombia Móvil|46,202|745|10|45.88.186.31:12773; 193.26.115.161:9238; 45.83.31.95:8319; 45.83.31.12:5075; 45.83.31.136:4820|
|AS10620|LACNIC-10620|35,046|1,221|11|45.83.31.95:14500; 193.26.115.189:8104; 45.83.31.136:5032; 45.153.34.67:2780; 45.88.186.31:1577|
|AS13489|LACNIC-13489|33,008|729|10|45.83.31.95:14990; 45.83.31.136:6613; 193.26.115.161:3359; 45.83.31.12:2025; 45.88.186.31:1678|
|AS19429|LACNIC-19429|10,811|591|20|45.83.31.95:4292; 91.92.242.165:1881; 45.153.34.67:1323; 45.88.186.31:1247; 45.83.31.136:596|
|AS14080|LACNIC-14080|10,000|361|14|45.83.31.95:3228; 45.83.31.136:1101; 45.88.186.31:928; 45.83.31.114:871; 193.26.115.161:816|
|AS52468|UFINET PANAMA S.A.|5,186|210|11|45.83.31.95:3700; 45.83.31.136:389; 185.208.159.212:285; 45.83.31.12:267; 45.88.186.31:165|
|AS27951|Media Commerce Partners S.A|4,459|103|9|45.83.31.95:4048; 45.83.31.136:176; 45.88.186.31:134; 45.83.31.12:36; 193.26.115.189:31|
|AS272977|GLOBALTRONIK SAS|4,260|13|2|45.83.31.95:4244; 45.83.31.12:16|
|AS264646|DOBLECLICK SOFTWARE E INGENERIA|3,747|22|8|45.83.31.95:3613; 91.92.242.165:80; 185.208.159.212:32; 45.83.31.12:12; 45.83.31.136:4|
|AS18678|LACNIC-18678|3,501|142|11|45.83.31.95:2756; 45.83.31.136:306; 193.26.115.189:132; 193.26.115.161:117; 45.83.31.12:59|
|AS262186|TV AZTECA SUCURSAL COLOMBIA|1,624|148|15|45.83.31.95:1116; 45.83.31.136:111; 193.26.115.189:104; 45.153.34.67:75; 91.92.243.40:38|
|AS26611|COMUNICACI�N CELULAR S.A. COMCEL S.A.|1,600|529|14|45.83.31.95:757; 45.83.31.136:253; 45.153.34.67:221; 193.26.115.189:117; 45.88.186.31:92|
|AS262191|LIBERTY NETWORKS DE COLOMBIA S.A.S|1,020|51|8|45.83.31.95:429; 45.153.34.67:217; 45.83.31.136:144; 45.83.31.35:112; 45.83.31.12:66|
|AS3549|LVLT-3549|910|68|14|45.83.31.95:311; 193.26.115.189:91; 45.153.34.67:79; 45.83.31.12:78; 91.92.242.165:73|
|AS3816|LACNIC-3816|792|203|8|45.83.31.12:317; 45.88.186.31:225; 45.83.31.136:150; 193.26.115.161:60; 45.83.31.95:23|

## Traffic characteristics

Monthly activity peaked in February 2026 with **135,693 matched flows**. The highest daily count was **18,650** on **2026-02-26**.

Top IOC-destination ports include 2929, 51820, 1994, 443, 3389, 2828, 2434, 909, 22, and 5000. These ports should be used as triage pivots, not as blanket indicators, because several are common service ports or are used by benign tunneling/VPN services.

## Threat reporting view

Campaign attribution by flow volume is dominated by CSIRT-PONAL weekly IOC bulletins: **407,586 flows** mapped to CSIRT-PONAL sourced P1 malware C2 indicators. BlindEagle / APT-C-36 DCRAT infrastructure produced **28,973 flows** across 14 observed IOC IPs, with `45.153.34.67` accounting for **14,217 flows** and **5,971 Colombia peer flows** in the top-country distribution. Broader LATAM Horabot / Casbaneiro / Metamorfo infrastructure was observed through `104.21.19.50`, but that IP has high false-positive risk because it is shared CDN-style infrastructure and should only be actioned with host, SNI, or URI context.

## Recommended CERT actions

1. Prioritize Colombian networks with repeated P1 IOC-destination flows, especially when the IOC-side port matches the IOC CSV reference port. Provide the AS owner with peer IP, IOC IP, timestamp range, ports, and the IOC source title.

2. Treat `45.83.31.95`, `45.88.186.31`, `45.83.31.136`, `193.26.115.161`, `193.26.115.189`, and `45.153.34.67` as the first response queue for Colombia-focused outreach because they combine high volume, Colombia peer concentration, and recent source reporting.

3. For BlindEagle / DCRAT related hits, ask recipient teams to search endpoint telemetry for PowerShell, JavaScript, Discord attachment retrieval, DCRAT process ancestry, and suspicious dynamic DNS usage. The flow evidence alone is not enough to identify the specific host-level infection chain.

4. For shared-service IPs such as Cloudflare, Discord, Archive.org, GitHub, Telegram, and similar platforms, do not block by IP-only. Use DNS, TLS SNI, HTTP host, URL path, user-agent, and endpoint process lineage.

5. Use the enriched CSV to open notification tickets. The `exact_ioc_port_match`, `ioc_priority`, `non_ioc_peer_country`, `non_ioc_peer_asn`, and `ioc_campaign_or_alert` columns provide a fast triage workflow.

## Caveats

NetFlow, sFlow, and IPFIX records often lack payload, DNS hostnames, TLS SNI, user identity, and endpoint process details. Flow direction should not be treated as session initiation with certainty. The `in_bytes` field may reflect sampled or collector-side accounting and should not be interpreted as complete transfer volume. The term peer is used for the non-IOC endpoint because a network match alone does not prove compromise.

## Source material preserved in IOC CSV

|Source org|Source title|URL|
|---|---|---|
|CSIRT-PONAL / Policía Nacional de Colombia|CSIRT-PONAL Boletín Semanal de IoC 017|https://cc-csirt.policia.gov.co/alertas-tips/2026|
|Zscaler ThreatLabz|BlindEagle targets Colombian government agency with Caminho and DCRAT|https://www.zscaler.com/blogs/security-research/blindeagle-targets-colombian-government-agency-caminho-and-dcrat|
|BlueVoyant|Augmented Marauder pushes new Casbaneiro variants via Horabot|https://www.bluevoyant.com/blog/augmented-marauder-pushes-new-casbaneiro-variants-via-horabot|
|ColCERT|AL-20260203-092 Phishing con robo biométrico|https://www.colcert.gov.co/800/articles-426289_COLCERT_AL__20260203__092_Alerta_sofisticacion_de_Phishing_con_robo_biometrico__IoCs.pdf|
|ColCERT|AL-20260414-099 Alerta campaña activa de malware multivectorial|https://www.colcert.gov.co/800/articles-433804_COLCERT_AL__20260414__099_Alerta_campana_activa_de_malware_multivectorial.pdf|
|RansomLook|LockBit 5.0 group infrastructure profile|https://www.ransomlook.io/group/lockbit5|
