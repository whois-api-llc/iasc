# Advisory IP Collision Analysis

This package correlates observed network telemetry with CSIRT Salud advisory IP indicators and adds port context for practical defender triage.

## Headline metrics

- Observed window: 2025-11-15 18:10:38 to 2026-05-13 06:53:23
- Collision records: 24,421
- Advisory IPs observed: 13 of 19
- Potential peer IPs: 3,459
- Potential peer netnames: 90
- Potential peer ASNs: 43
- Exact advisory IP:port matches: 0
- Colombia-coded peer flows in this slice: 0

## Interpretation

A peer IP or network is not automatically a victim. Treat the non-advisory side as a notification lead until the owner validates local firewall, DNS, proxy, EDR, packet, and service logs.
